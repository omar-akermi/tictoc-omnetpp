
#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

class Noeud : public cSimpleModule
{
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(Noeud);

void Noeud::initialize()
{

    if (strcmp("tic", getName()) == 0) {

        cMessage *msg = new cMessage("Hello!");
        send(msg, "out");
    }
}

void Noeud::handleMessage(cMessage *msg)
{

    send(msg, "out");
}

